 <?php
	class Videos extends MX_Controller 
	{ 
		function __construct()
		{
			parent::__construct();

		}

//<a href="<?=//base_url()?videos/watch/<?=$row->id?"> <h4 style="color:white;"><?=$row->item_description?/></h4></a>




function index(){
$this->load->view('views');
}


function watch_video(){
    
     $video= $this->uri->segment(3);
    $video_query = $this->db->query("SELECT * FROM `store_items` WHERE `item_url`='$video'");
    $video_array = $video_query->row();
    $data['watch_videos'] = $video_array->big_pic;
    
    $this->load->view('views4', $data);
    
    
    
    
}



function galleries()
{
    $data['id'] = $this->uri->segment(3);
    
     $data['view_file'] = "galleries";
        $this->load->module('templates'); 
        $this->templates->public_bootstrap($data);
}


function watch(){
    
     $data['id'] = $this->uri->segment(3);
    
     $data['view_file'] = "views";
        $this->load->module('templates'); 
        $this->templates->public_bootstrap($data);
}





function get($order_by)
{
    $this->load->model('mdl_videos');
    $query = $this->mdl_videos->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by) 
{
    if ((!is_numeric($limit)) || (!is_numeric($offset))) {
        die('Non-numeric variable!');
    }

    $this->load->model('mdl_videos');
    $query = $this->mdl_videos->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_where($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('mdl_videos');
    $query = $this->mdl_videos->get_where($id);
    return $query;
}

function get_where_custom($col, $value) 
{
    $this->load->model('mdl_videos');
    $query = $this->mdl_videos->get_where_custom($col, $value);
    return $query;
}

function _insert($data)
{
    $this->load->model('mdl_videos');
    $this->mdl_videos->_insert($data);
}

function _update($id, $data)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('mdl_videos');
    $this->mdl_videos->_update($id, $data);
}

function _delete($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('mdl_videos');
    $this->mdl_videos->_delete($id);
}

function count_where($column, $value) 
{
    $this->load->model('mdl_videos');
    $count = $this->mdl_videos->count_where($column, $value);
    return $count;
}

function get_max() 
{
    $this->load->model('mdl_videos');
    $max_id = $this->mdl_videos->get_max();
    return $max_id;
}

function _custom_query($mysql_query) 
{
    $this->load->model('mdl_videos');
    $query = $this->mdl_videos->_custom_query($mysql_query);
    return $query;
}


  function item_check($str)
  {
  	$item_url = url_title($str);
  	$mysql_query ="select * from store_items where item_title='$str' and item_url = '$item_url' ";

  	$update_id = $this->uri->segment(3);
  	if (is_numeric(($update_id))) {
  		# this is an update...
          $mysql_query.=" and id!=$update_id";
  	}

  	$query = $this->_custom_query($mysql_query);
  	$num_rows = $query->num_rows()
;


          if ($num_rows>0)
          {
                  $this->form_validation->set_message('item_check', 'The item title that you sunmitted is not available');
                  return FALSE;
          }
          else
          {
                  return TRUE;
          }
  }

	}