<?php

$sqlG = $this->db->query("SELECT * FROM item_galleries WHERE id ='$id' ");

$rowG = $sqlG->row();

 $productId = $rowG->parent_id;
 
 $sql = $this->db->query("SELECT * FROM item_galleries WHERE parent_id = '$productId' ");



?>

<div class="container">
	<div class="row col-md-9">
    	<div class="video-responsive">
       <video width="100%" height="50%" controls controlsList="nodownload">
  <source src="<?=base_url() ?>item_galleries_pics/<?= $rowG->picture ?>" type="video/mp4">
  <source src="<?=base_url() ?>item_galleries_pics/<?= $rowG->picture ?>" type="video/ogg">
Your browser does not support the video tag.
</video>
        </div>
	</div>
	<div class="row col-md-1">
	    
	    </div>
	
	<div class="row col-md-2">
	      	<?php 	foreach($sql->result() as $row){ ?>
	  	<div class="video-responsive">
	  	    <a href="<?=base_url()?>videos/galleries/<?=$row->id?>">
       <video width="100%" height="20%" >
  
      <source src="<?=base_url() ?>item_galleries_pics/<?= $row->picture ?>" type="video/mp4">
  <source src="<?=base_url() ?>item_galleries_pics/<?= $row->picture ?>" type="video/ogg">
  
</video>
</a>
 </div>
  <?php } ?>

 
	   
</div>
</div>